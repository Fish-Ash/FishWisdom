
# 求列表均值
def E(L):
    return sum(L)/len(L)

# 求矩阵转置
def T(L):
    return [[L[j][i] for j in range(len(L))] for i in range(len(L[0]))]

# 计算距离的平方
def dis(p1, p2):
    sum = 0
    for i in range(len(p1)):
        sum += (p1[i] - p2[i])**2
    return sum