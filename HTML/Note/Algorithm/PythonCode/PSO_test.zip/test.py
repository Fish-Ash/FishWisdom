import numpy as np
from SomeFun import *


print(np.random.rand(1))